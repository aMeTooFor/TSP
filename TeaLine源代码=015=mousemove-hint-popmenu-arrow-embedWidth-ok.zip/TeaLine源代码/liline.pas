unit liline;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  tline;

type
  { TTLiLine }
  TTLiLine = class(TForm)
    Button1: TButton;
    Label1: TLabel;
    ScrollBox1: TScrollBox;
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormResize(Sender: TObject);
    procedure Label1MouseMove(Sender: TObject; Shift: TShiftState; X, Y: integer);
  private

  public

  end;

var
  TLiLine: TTLiLine;
  oneline: tealine;

implementation

//uses  liline;
{$R *.lfm}

{ TTLiLine }
function S_abc(A, B, C: TPoint): double;
var
  aa, bb, cc, s: double;
begin
  // 计算三边长度
  aa := Sqrt(Sqr(B.X - C.X) + Sqr(B.Y - C.Y)); // BC边长度
  bb := Sqrt(Sqr(A.X - C.X) + Sqr(A.Y - C.Y)); // AC边长度
  cc := Sqrt(Sqr(A.X - B.X) + Sqr(A.Y - B.Y)); // AB边长度

  // 计算半周长
  s := (aa + bb + cc) / 2;

  // 应用海伦公式计算面积
  Result := Sqrt(s * (s - aa) * (s - bb) * (s - cc));
end;

procedure TTLiLine.Button1Click(Sender: TObject);
var
  i: integer;
begin
  if 1 = 1 then
  begin
    oneline := tealine.Create(self);
    oneline.Parent := self;
    oneline.x1 := 100;
    oneline.y1 := 100;
    oneline.x2 := 500;
    oneline.y2 := 500;
    oneline.arrow:=true;
    //oneline.Repaint;
    // oneline.Invalidate;
    oneline.paint;

    oneline := tealine.Create(self);
    oneline.Parent := self;
    oneline.x1 := 500;
    oneline.y1 := 100;
    oneline.x2 := 100;
    oneline.y2 := 500;
    //oneline.Repaint;
    // oneline.Invalidate;
    oneline.paint;
  end;

  if 1 = 1 then
  begin
    oneline := tealine.Create(self);
    oneline.Name:='line1';
    oneline.Parent := self.ScrollBox1;
    oneline.x1 := 10;
    oneline.y1 := 10;
    oneline.x2 := 200;
    oneline.y2 := 200;
   // oneline.wwwHint:='www123';
     oneline.Hint:='www123';
    oneline.ShowHint:=true;
   // oneline.Repaint;
    // oneline.Invalidate;
    oneline.arrow:=true;
    oneline.paint;

    oneline := tealine.Create(self);
    oneline.Name:='line2';
    oneline.Parent := self.ScrollBox1;
    oneline.x1 := 200;
    oneline.y1 := 10;
    oneline.x2 := 10;
    oneline.y2 := 200;
    //oneline.arrow:=true;
  //  oneline.wwwHint:='www111';
    oneline.Hint:='www111';
    oneline.ShowHint:=true;
    //oneline.Repaint;
    // oneline.Invalidate;
    oneline.paint;
    //application.ProcessMessages;
    //oneline.paint;

     oneline := tealine.Create(self);
    oneline.Name:='line3';
    oneline.Parent := self.ScrollBox1;
    oneline.x1 := 20;
    oneline.y1 := 200;
    oneline.x2 := 200;
    oneline.y2 := 200;
    oneline.arrow:=true;
  //  oneline.wwwHint:='www111';
    oneline.Hint:='wwwline3';
    oneline.ShowHint:=true;
    //oneline.Repaint;
    // oneline.Invalidate;
    oneline.paint;


  end;
end;

procedure TTLiLine.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  if oneline <> nil then
    oneline.Free;
end;

procedure TTLiLine.FormResize(Sender: TObject);
begin
  application.ProcessMessages;
end;

procedure TTLiLine.Label1MouseMove(Sender: TObject; Shift: TShiftState; X, Y: integer);
var
  a, b, c: TPoint;
begin
  a.X := x;
  a.y := Y;
  b.x := tealine(Sender).x1;
  b.y := tealine(Sender).y1;
  c.x := tealine(Sender).x2;
  c.y := tealine(Sender).y2;

  if S_abc(a, b, c) < 0.1 then
  begin
    tealine(Sender).Canvas.Brush.Color := clblue;
    tealine(Sender).Canvas.Line(b.x, b.y, c.x, c.y);
  end;
end;

end.
