unit TSP_form;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, Spin, ComCtrls, TSPPaint, TSP_EA_I, TSP_I, ant, aco,
  SHELLAPI,
  TSPshow, math,
  RzButton, RzBHints, RzLine, RzTabs, Vcl.Menus, RzLabel, Data.DB,
  Data.Win.ADODB, Vcl.Mask, RzEdit;

type
  TMainForm = class(TForm)
    Panel2: TPanel;

    StatusBar1: TStatusBar;
    OpenDialog1: TOpenDialog;
    SaveDialog1: TSaveDialog;
    RzBalloonHints1: TRzBalloonHints;
    RzPageControl1: TRzPageControl;
    TabSheet5: TRzTabSheet;
    TabSheet6: TRzTabSheet;
    TabSheet7: TRzTabSheet;
    TabSheet8: TRzTabSheet;
    TabSheet9: TRzTabSheet;
    help: TRzButton;
    about: TRzButton;
    Label2: TLabel;
    EditNoCities: TSpinEdit;
    ButtonCreateCities: TButton;
    exportPoints: TButton;
    importPoints: TButton;
    help2: TButton;
    customLength: TButton;
    Label5: TLabel;
    Memo3: TMemo;
    Label3: TLabel;
    EditPopulationSize: TSpinEdit;
    ButtonCreatePop: TButton;
    Label7: TLabel;
    EditGens: TSpinEdit;
    ButtonRun: TButton;
    onlyshowgenerate: TButton;
    Memo1: TMemo;
    Label1: TLabel;
    antNums: TSpinEdit;
    createant: TButton;
    Label4: TLabel;
    gMAX_GEN: TSpinEdit;
    runant: TButton;
    onlyshowant: TButton;
    Memo2: TMemo;
    ProgressBar1: TProgressBar;
    SpinEdit3: TSpinEdit;
    Label6: TLabel;
    Label8: TLabel;
    SpinEdit4: TSpinEdit;
    Label9: TLabel;
    SpinEdit5: TSpinEdit;
    Label10: TLabel;
    alpha: TSpinEdit;
    Label11: TLabel;
    beta: TSpinEdit;
    Label12: TLabel;
    rho: TSpinEdit;
    Label13: TLabel;
    pheromone: TSpinEdit;
    PopupMenu1: TPopupMenu;
    N1: TMenuItem;
    RzPageControl2: TRzPageControl;
    TabSheet1: TRzTabSheet;
    TabSheet2: TRzTabSheet;
    runonebyone: TButton;
    onebyoneHelp: TRzButton;
    onlyshowonebyone: TButton;
    Memo6: TMemo;
    ProgressBar4: TProgressBar;
    runDy: TButton;
    DyHelp: TRzButton;
    onlyshowdy: TButton;
    Memo4: TMemo;
    ProgressBar3: TProgressBar;
    generateHelp: TRzButton;
    RzLabel2: TRzLabel;
    RzLabel3: TRzLabel;
    runfire: TRzButton;
    Memo8: TMemo;
    ProgressBar5: TProgressBar;
    onlyshowfire: TButton;
    SpinEdit10: TSpinEdit;
    SpinEdit11: TSpinEdit;
    SpinEdit12: TSpinEdit;
    SpinEdit13: TSpinEdit;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    intonebyone: TRzButton;
    ADOConnection1: TADOConnection;
    ADO1: TADOQuery;
    ADO2: TADOQuery;
    RzLabel1: TRzLabel;
    RzEdit1: TRzEdit;
    ADO11: TADOQuery;
    ADO22: TADOQuery;
    TabSheet3: TRzTabSheet;
    RzPageControl3: TRzPageControl;
    TabSheet4: TRzTabSheet;
    runLKH: TButton;
    LKHini: TRzButton;
    onlyshowLKH: TButton;
    Memo9: TMemo;
    ProgressBar6: TProgressBar;
    TabSheet10: TRzTabSheet;
    RUNCCD: TButton;
    ButtonCCD: TButton;
    RzButtonCCD: TRzButton;
    MemoCCD: TMemo;
    ProgressBarCCD: TProgressBar;
    showAllRoads: TRzButton;
    N2: TMenuItem;
    Label18: TLabel;
    Label19: TLabel;
    delta: TSpinEdit;
    antsHelp: TRzButton;
    TabSheet11: TRzTabSheet;
    Label20: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    runPSO: TRzButton;
    onlyshowPSO: TButton;
    PSOLine: TMemo;
    PSOnum: TSpinEdit;
    PSOwe: TSpinEdit;
    PSOw: TSpinEdit;
    PSOws: TSpinEdit;
    Label24: TLabel;
    Label25: TLabel;
    Label26: TLabel;
    Label27: TLabel;
    PSOVv: TSpinEdit;
    PSOc1: TSpinEdit;
    PSOc2: TSpinEdit;
    PSOiter: TSpinEdit;
    ScrollBox_Panel: TPanel;
    PanelDisp: TScrollBox;
    Shape1: TShape;
    RzLine2: TRzLine;
    Memo5: TMemo;
    ProgressBar2: TProgressBar;
    Memo_SaveToTxT: TMemo;
    Memo7: TMemo;
    PSOhelp: TRzButton;
    procedure FormCreate(Sender: TObject);
    procedure ButtonCreateCitiesClick(Sender: TObject);
    procedure ButtonCreatePopClick(Sender: TObject);
    procedure ButtonStepClick(Sender: TObject);
    procedure ButtonRunClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure createantClick(Sender: TObject);
    procedure runantClick(Sender: TObject);
    procedure exportPointsClick(Sender: TObject);
    procedure importPointsClick(Sender: TObject);
    procedure customLengthClick(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure onlyshowgenerateClick(Sender: TObject);
    procedure onlyshowantClick(Sender: TObject);
    procedure runDyClick(Sender: TObject);
    procedure onlyshowdyClick(Sender: TObject);
    procedure help2Click(Sender: TObject);
    procedure helpClick(Sender: TObject);
    procedure aboutClick(Sender: TObject);
    procedure Shape1MouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Shape2MouseMove(Sender: TObject; Shift: TShiftState;
      X, Y: Integer);
    procedure Shape2MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure RzLine2MouseEnter(Sender: TObject);
    procedure RzLine2MouseLeave(Sender: TObject);
    procedure runonebyoneClick(Sender: TObject);
    procedure onlyshowonebyoneClick(Sender: TObject);
    procedure DyHelpClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure onebyoneHelpClick(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure generateHelpClick(Sender: TObject);
    procedure runfireClick(Sender: TObject);
    procedure onlyshowfireClick(Sender: TObject);
    procedure intonebyoneClick(Sender: TObject);
    procedure LKHiniClick(Sender: TObject);
    procedure runLKHClick(Sender: TObject);
    procedure onlyshowLKHClick(Sender: TObject);
    procedure RUNCCDClick(Sender: TObject);
    procedure RzButtonCCDClick(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure ButtonCCDClick(Sender: TObject);
    procedure antsHelpClick(Sender: TObject);
    procedure runPSOClick(Sender: TObject);
    procedure onlyshowPSOClick(Sender: TObject);
    procedure PSOHelpClick(Sender: TObject);
  private
    { Private declarations }
    fGenerations: Integer;

    BreederCrossover: IBreeder;
    Examiner: ITSPExaminer;
    Creator: ITSPCreator;
    KillerPercentage: IKillerPercentage;
    Mutator: ITSPMutator;
    Population: IPopulation;
    ParentSelectorTournament: IParentSelector;

    ArrFit: array of TFloat;
    ArrFitLen: Integer;
    ArrFitPos: Integer;
    BitmapF: TBitmap;
    procedure PopulationChange(Sender: TObject);
    procedure SetGenerations(const Value: Integer);
    procedure ClearGraph;
    procedure DrawFit;
    procedure Plot(D: TFloat);
    procedure pFitPaint(Sender: TObject);
    procedure DisplayPaint(Sender: TObject);
  public
    { Public declarations }
    isdebug: Integer;
    X: array of Integer;
    Y: array of Integer;
    Z: array of Double;
    PMemo: array of string;
    isload: Integer;
    showall: Integer;
    Display: TshowTSP;
    Controller: ITSPController;
    R_SGA: ITSPIndividual;
    R_ACO: ITSPIndividual;
    R_DP: ITSPIndividual;
    R_Branch: ITSPIndividual;
    R_TFire: ITSPIndividual;
    R_LKH: ITSPIndividual;
    R_CCD: ITSPIndividual;
    R_PSO: ITSPIndividual;
    oriP: TPoint;
    property Generations: Integer read fGenerations write SetGenerations;
    function MoveLineLi(eee: TRzLine; p1x, p1y, p2x, p2y: Integer;
      truelength222, direct: string): boolean;
    procedure LKH_printPath;
    procedure CCD_printPath;
    function showissetcity(n: Integer): Integer;

  end;

const
  XorKey: array [0 .. 7] of Byte = ($B2, $09, $BB, $55, $93, $6D, $44, $47);

  // �ַ���������
var
  MainForm: TMainForm;
  aco: TACO;
  Origin: TPoint;
  LineBeforeColor, LableBeforeColor, MyLineColor: TColor;
  mouseMoveCount, PCount: Integer;
  BranchStop: boolean;
  wwwname: string;
  maincapiton, addcaption: string;

implementation

uses
  TSP_EA, dp, U_OK, Branch, U_A1, U_A2, IdHashMessageDigest, TFire, U_LKH_ini,
  PSO, ExeStr;

{$R *.DFM}

function Enc(Str: string): string; // �ַ����ܺ���  �@���õ�һ���������
var
  i, j: Integer;
begin
  Result := '';
  j := 0;
  for i := 1 to Length(Str) do
  begin
    Result := Result + IntToHex(Byte(Str[i]) xor XorKey[j], 2);
    j := (j + 1) mod 8;
  end;
end;

function Dec(Str: string): string; // �ַ����ܺ���
var
  i, j: Integer;
begin
  Result := '';
  j := 0;
  for i := 1 to Length(Str) div 2 do
  begin
    Result := Result + Char(StrToInt('$' + Copy(Str, i * 2 - 1, 2))
      xor XorKey[j]);
    j := (j + 1) mod 8;
  end;
end;
// ���ܺ���

function UncrypKey(Src: string; Key: string): string;
var
  idx, i, j: Integer;
  KeyLen: Integer;
  KeyPos: Integer;
  offset: Integer;
  dest: widestring;
  SrcPos: Integer;
  SrcAsc: Integer;
  TmpSrcAsc: Integer;
  Range, ookk, ok: Integer;
  www: widestring;
begin
  if Length(Src) = 2 then
  begin
    Result := '';
    exit;
  end;
  KeyLen := Length(Key);
  if KeyLen = 0 then
    Key := 'Think   Space ';
  KeyPos := 0;
  SrcPos := 0;
  SrcAsc := 0;
  Range := 256;
  offset := StrToInt('$' + Copy(Src, 1, 2));
  SrcPos := 3;
  ookk := 1;
  repeat
    SrcAsc := StrToInt('$' + Copy(Src, SrcPos, 2));
    if KeyPos < KeyLen then
      KeyPos := KeyPos + 1
    else
      KeyPos := 1;
    TmpSrcAsc := SrcAsc xor ord(Key[KeyPos]);

    if ookk = 1 then
    begin
      ok := TmpSrcAsc;
    end
    else
    begin
      ok := ok * 16 * 16 + TmpSrcAsc;
    end;

    if ookk = 1 then
    begin
      ookk := ookk + 1;
    end
    else
    begin
      dest := dest + widechar(ok);
      ookk := 1;
    end;
    SrcPos := SrcPos + 2;
  until SrcPos >= Length(Src);
  Result := dest;

  { result:='';
    j:=0;
    for i:=0 to length(Dest)-1 do
    begin
    j:=i*2+1;
    result:=result+  chr(ord(dest[j])*16+ord(dest[j+1]))

    end;

  }

end;
function Get_TAIL500_MD5ByFileName(CheckStr: string): string;
var
  s: TExeStream;
  a: ansiChar;
  k: Byte;
  i: Integer;
  www: ansistring;
begin
  www := '';
  try
    s := TExeStream.Create(Application.ExeName, True);
    for i := 0 to 500 do
    begin
      k := s.Read(a, 1);
      if k <> 0 then
        www := www + a;
      if k = 0 then
        break;

    end;
    s.Free;
  except

  end;
  // showmessage(www);
  // FA1.Caption := 'www';
  // FA1.RzMemo1.Text := www;
  // FA1.ShowModal;

  Result := widestring(www);

end;


function Get_sub500_MD5ByFileName(CheckStr: string): string;
var
  MyMD5: TIdHashMessageDigest5;
  TempFS: TFileStream;
  www: tmemorystream;
  subiii:integer;
begin
  TempFS := TFileStream.Create(CheckStr, fmOpenRead or fmSharedenyNone);
  www := tmemorystream.Create;
  subiii  := length( Get_TAIL500_MD5ByFileName(paramstr(0)) )+8;
  www.CopyFrom(TempFS, TempFS.Size - subiii);
  www.Position:=0;
  MyMD5 := TIdHashMessageDigest5.Create;
  try
    // Result := MyMD5.AsHex(MyMD5.HashValue(TempFS));
    // Result := MyMD5.HashStringAsHex(TempFS,indyTextEncoding_UTF8).ToLower;
    // Result := MyMD5.HashStreamAsHex(TempFS).ToLower;
    Result := MyMD5.HashStreamAsHex(www).ToLower;
    // MyMD5.HashStreamAsHex()
  finally
    MyMD5.Free;
    TempFS.Free;
    www.Free;
  end;
end;



procedure TMainForm.FormCreate(Sender: TObject);
begin
  Randomize;
  Display := TshowTSP.Create(self, PanelDisp);
  Display.SetRanges(0.0, 11.0, 0.0, 11.0, 1.0);
  Display.BgColor := clWhite;
  Display.Clear;

  Controller := TTSPController.Create;
  Controller.Xmin := Display.Xmin;
  Controller.Xmax := Display.Xmax;
  Controller.Ymin := Display.Ymin;
  Controller.Ymax := Display.Ymax;

  Display.Controller := Controller;

  Creator := TTSPCreator.Create;
  Creator.Controller := Controller;

  BreederCrossover := TTSPBreederCrossover.Create;

  Examiner := TTSPExaminer.Create;
  Examiner.Controller := Controller;

  KillerPercentage := TKillerPercentage.Create;

  Mutator := TTSPMutator.Create;

  ParentSelectorTournament := TParentSelectorTournament.Create;

  Population := TPopulation.Create;
  Population.Breeder := BreederCrossover;
  Population.Examiner := Examiner;
  Population.Creator := Creator;
  Population.Killer := KillerPercentage;
  Population.Mutator := Mutator;
  Population.ParentSelector := ParentSelectorTournament;
  Population.OnChange := PopulationChange;
  isload := 0;
  showall := 0;
  wwwname := '��������~��������'; // TSP�����㷨С���� V6.0    QQ:165442523  ������������  2024��1��
  // self.Caption := 'TSP�����㷨С���� V7.0    QQ:165442523  ������' + wwwname +
  // '  2024��1�� '+'  ����������ʵ������ȵ��������ļ�';
  wwwname := 'ѧϰTSP�㷨';
  maincapiton := 'TSP�����㷨С���� V7.0    QQ:165442523  ������' + wwwname +
    '  2024��2�� ';
  addcaption := '  ����������ʵ������ȵ��������ļ�';
  self.Caption := maincapiton + addcaption;
end;

procedure TMainForm.FormDestroy(Sender: TObject);
begin
  BitmapF.Free;
  if aco <> nil then
    freeandnil(aco);
end;

procedure TMainForm.SetGenerations(const Value: Integer);
begin
  fGenerations := Value;
  // StatusBar1.Panels[0].Text := 'Gens: ' + IntToStr(Value);
end;

procedure TMainForm.Shape1MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  TShape(Sender).Tag := 1;
  mouseMoveCount := 0;
  // TShape(Sender).Hint
  Origin.X := X;
  Origin.Y := Y;
end;

procedure TMainForm.Shape2MouseMove(Sender: TObject; Shift: TShiftState;
  X, Y: Integer);
var
  www: TPoint;
  i: Integer;
  qq: TComponent;
  p1x, p1y, p2x, p2y: Integer;
  truelength222: string;
  truelength333: Double;
  direct: string;
  pcode1pp, pcode2pp: TShape;
  eee: TRzLine;
  tmpstr, tmpstr0: string;
begin
  if TShape(Sender).Tag = 1 then
  begin
    mouseMoveCount := mouseMoveCount + 1;
    if mouseMoveCount = 2 then
    begin
      mouseMoveCount := 0;
      www.X := X;
      www.Y := Y;
      // www := TShape(Sender).ScreenToClient(Origin);
      // Origin:=  TPoint( @application.Tag);

      TShape(Sender).Left := TShape(Sender).Left + (www.X - Origin.X);
      TShape(Sender).Top := TShape(Sender).Top + (www.Y - Origin.Y);
      // TShape(Sender).Left := X;
      // TShape(Sender).Top := Y;
      /// /////////
      {
        for i := self.ComponentCount - 1 downto 0 do
        begin
        if ((self.Components[i] is tlabel)) then
        begin
        if uppercase(self.Components[i].Name) = 'M' + TShape(Sender).Name then
        begin
        tlabel(self.Components[i]).Left := TShape(Sender).Left + 10;
        tlabel(self.Components[i]).Top := TShape(Sender).Top;
        continue;
        end;
        end;

        //////////////

        end; }
      qq := nil;
      qq := self.FindComponent('M' + TShape(Sender).Name);
      if qq <> nil then
      begin
        TLabel(qq).Left := TShape(Sender).Left + 10;
        TLabel(qq).Top := TShape(Sender).Top;

      end;
      // caption := 'left=' + inttostr(TShape(Sender).Left) + ';top=' + inttostr(TShape(Sender).Top) +
      // ';X=' + inttostr(x) + ';Y=' + inttostr(y);
      /// ###########
      /// ����Ҫ   Origin:=www; ����Ҫ   Origin:=www; ����Ҫ   Origin:=www;
      /// /##########
      PanelDisp.ScrollInView(TShape(Sender));
      /// /�˾����й�����ʱ���ܺúܺã�������
      for i := self.ComponentCount - 1 downto 0 do
        if ((self.Components[i] is TRzLine)) then
        begin
          // if ((pos(TShape(Sender).Name + 'P', uppercase(self.Components[i].Name)) > 0) or
          // (pos(TShape(Sender).Name + 'E', uppercase(self.Components[i].Name)) > 0)) then
          eee := nil;
          tmpstr0 := self.Components[i].Name;
          tmpstr0 := stringreplace(tmpstr0, '_1', '', []);
          tmpstr0 := stringreplace(tmpstr0, '_2', '', []);
          tmpstr0 := stringreplace(tmpstr0, '_3', '', []);
          tmpstr0 := stringreplace(tmpstr0, '_4', '', []);
          tmpstr0 := stringreplace(tmpstr0, '_5', '', []);
          if ((pos(TShape(Sender).Name + 'P', uppercase(tmpstr0 + 'E')) > 0))
          then

          begin
            eee := TRzLine(self.Components[i]);
            tmpstr := eee.Name;
            tmpstr := stringreplace(tmpstr, '_1', '', []);
            tmpstr := stringreplace(tmpstr, '_2', '', []);
            tmpstr := stringreplace(tmpstr, '_3', '', []);
            tmpstr := stringreplace(tmpstr, '_4', '', []);
            tmpstr := stringreplace(tmpstr, '_5', '', []);
            tmpstr := stringreplace(tmpstr, TShape(Sender).Name + 'P', '', []);
            tmpstr := stringreplace(tmpstr, 'E', '', []);
            tmpstr := 'P' + tmpstr;

            pcode1pp := TShape(Sender);
            pcode2pp := TShape(self.FindComponent(tmpstr));

          end;
          if ((pos(TShape(Sender).Name + 'E', uppercase(tmpstr0 + 'E')) > 0))
          then

          begin
            eee := TRzLine(self.Components[i]);
            pcode2pp := TShape(Sender);
            eee := TRzLine(self.Components[i]);
            tmpstr := eee.Name;
            tmpstr := stringreplace(tmpstr, '_1', '', []);
            tmpstr := stringreplace(tmpstr, '_2', '', []);
            tmpstr := stringreplace(tmpstr, '_3', '', []);
            tmpstr := stringreplace(tmpstr, '_4', '', []);
            tmpstr := stringreplace(tmpstr, '_5', '', []);
            tmpstr := tmpstr + 'E';
            tmpstr := stringreplace(tmpstr, TShape(Sender).Name + 'E', '', []);

            pcode1pp := TShape(self.FindComponent(tmpstr));

          end;
          if eee <> nil then
          begin
            p1x := pcode1pp.Left + 5;
            p1y := pcode1pp.Top + 5;
            p2x := pcode2pp.Left + 5;
            p2y := pcode2pp.Top + 5;
            // if RadioButton4.Checked then
            begin
              truelength222 := eee.Hint;
            end;
            // else
            begin
              truelength222 := '';
              truelength333 :=
                (sqrt(power((p1x - p2x), 2) + power((p1y - p2y), 2)));

              truelength222 := stringreplace(format('%f', [truelength333]),
                '.00', '', []);

            end;
            MoveLineLi(eee, p1x, p1y, p2x, p2y, truelength222, '');
          end;
          // continue;
        end;
    end;
  end;

end;

procedure TMainForm.Shape2MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var
  nn: string;
  ii: Integer;
  tt, pp: TPoint3D;
  w0, w1, p1, p2, ppp: TPoint;
begin
  if Button = mbRight then
  begin
    // PopupMenu1.Popup(TShape(Sender).Left+X,TShape(Sender).top+Y);
    w0.X := X;
    w0.Y := Y;
    w1 := TShape(Sender).ClientToScreen(w0);
    N1.Hint := TShape(Sender).Name;
    PopupMenu1.Popup(w1.X, w1.Y);
    if TShape(Sender).Tag = 1 then
      TShape(Sender).Tag := 0;
    exit;
  end;
  if TShape(Sender).Tag = 1 then
  begin
    mouseMoveCount := 2;
    TShape(Sender).OnMouseMove(Sender, Shift, X, Y);

    TShape(Sender).Tag := 0;
    nn := stringreplace(TShape(Sender).Name, 'P', '', []);
    ii := StrToInt(nn);
    // PanelDisp.
    // ppp:= PanelDisp.ClientOrigin;
    // tt.X := ppp.X+ TShape(Sender).Left + 5;
    // tt.Y := ppp.Y+ TShape(Sender).Top + 5;
    tt.X := oriP.X - self.Shape1.Left + TShape(Sender).Left + 5;
    tt.Y := oriP.Y - self.Shape1.Top + TShape(Sender).Top + 5;
    {
      p1.X := X;
      p1.Y := Y;
      p2 := TShape(Sender).ClientToScreen(p1);
      p1 := PanelDisp.ScreenToClient(p2);
      tt.X := p1.X;
      tt.Y := p1.Y;
    }
    /// /���ڷ���������BUG���ڳ���ʱ����ȷ��
    /// ��������ʱ��ȷ���϶�����ʱ��BUG
    /// ֤ʵ�������ȷʵ�����˴�BUG�� ���������Բ�̫�еģ�δ������
    // pp:=MainForm.Display.Controller.Cities[ii];// := tt;
    // pp:=tt;  SetCity(I: Integer;const Value: TPoint3D);
    // if MainForm.Display.Controller.CityCount then

    MainForm.Display.Controller.SetCity(ii, tt);
    if Length(MainForm.X) > 0 then
    begin
      MainForm.X[ii] := trunc(tt.X);
      MainForm.Y[ii] := trunc(tt.Y);
    end;
    ButtonCreatePop.Enabled := True;
    ButtonRun.Enabled := false;
    createant.Enabled := True;
    runant.Enabled := false;

  end;
end;

function TMainForm.showissetcity(n: Integer): Integer;
begin
  if MainForm.Display.Controller.CityCount = 0 then
  begin
    showmessage('�����������ǩҳ�������������');
    // exit;
    abort;
  end;
end;

procedure TMainForm.ButtonCCDClick(Sender: TObject);
begin
  // showall := 0;
  // Display.DrawMapWithRoute(nil);
  showall := 7;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.ButtonCreateCitiesClick(Sender: TObject);
var
  www: Tstringlist;
  i: Integer;
begin
  if EditNoCities.Value < 5 then
  begin
    // showmessage('�ʵ�����������5');
    // exit;
  end;

  Population.Clear;
  Generations := 0;
  ClearGraph;
  isload := 0;
  if aco <> nil then
    freeandnil(aco);
  if R_SGA <> nil then
    R_SGA := nil; // ���ֲ���FREE�ģ�������û��FREE
  if R_ACO <> nil then
    R_ACO := nil; // ���ֲ���FREE�ģ�������û��FREE
  if R_DP <> nil then
    R_DP := nil; // ���ֲ���FREE�ģ�������û��FREE
  if R_Branch <> nil then
    R_Branch := nil; // ���ֲ���FREE�ģ�������û��FREE
  if R_TFire <> nil then
    R_TFire := nil;
  // ������������Ĳ���FREE������Խ��Խ����Ҫ���´򿪻�����WIN��
  if R_LKH <> nil then
    R_LKH := nil;
  if R_CCD <> nil then
    R_CCD := nil;
  Display.Controller.CityCount := EditNoCities.Value;
  // TSP_EA.pas��Լ830��λ����TTSPController.SetCityCount��RandomCities��
  // ������������󣬲������Ķ����⣬��������������
  Display.DrawMap;
  ButtonCreatePop.Enabled := True;
  ButtonRun.Enabled := false;
  runant.Enabled := false;

  addcaption := '  ��������ʵ���:' + inttostr(EditNoCities.Value);
  self.Caption := maincapiton + addcaption;

  if isdebug = 1 then
  begin
    // isdebug=1�Զ����棬Ϊ�˲���ʱ������BUG����û�б����������֮���¡�
    www := Tstringlist.Create;
    www.Add('//��ע�⣬��Ŵ�0��ʼ�����Ҫ����������Ҫ������أ�ĩβΪ�գ���Ҫ�����ַ�');
    www.Add('//����ֵΪ��Ļ�������ֻ꣬����Ϊ��������������Ϊ�����������Դ�����Ļ���Զ����ֹ�������');
    for i := 0 to EditNoCities.Value - 1 do
    begin
      if MainForm.PMemo[i] = 'P' + inttostr(i) then
        www.Add('P' + inttostr(i) + ': x=' +
          floattostr((MainForm.Display.Controller.Cities[i].X)) + ';y=' +
          floattostr((MainForm.Display.Controller.Cities[i].Y)))
      else
        www.Add('P' + inttostr(i) + '(' + MainForm.PMemo[i] + '): x=' +
          floattostr((MainForm.Display.Controller.Cities[i].X)) + ';y=' +
          floattostr((MainForm.Display.Controller.Cities[i].Y)))
    end;
    // www.SaveToFile('c:\data.txt');
    www.SaveToFile(extractfilepath(paramstr(0)) + 'temp0123456789\' +
      formatdatetime('dd-hhmmss', now()) + '.txt');
    www.Free;

  end;
end;

procedure TMainForm.ButtonCreatePopClick(Sender: TObject);
const
  D = 5;
begin
  self.showissetcity(0);
  Population.Initialise(EditPopulationSize.Value);
  R_SGA := (Population[0] as ITSPIndividual);
  Display.DrawMapWithRoute(Population[0] as ITSPIndividual);
  // Display.OnPaint := DisplayPaint;
  Generations := 0;

  DrawFit;

  ButtonRun.Enabled := True;

end;

procedure TMainForm.CCD_printPath;
var
  CCDRoad: Tstringlist;
  New: ITSPIndividual;
  path: string;
  i: Integer;
  sqr0: Double;
  x1, y1, x2, y2, j, ii, jj: Integer;
begin
  path := extractfilepath(paramstr(0)) + 'concorde\';
  CCDRoad := Tstringlist.Create;
  CCDRoad.LoadFromFile(path + 'attwww.sol');
  CCDRoad.Text := stringreplace(CCDRoad.Text, ' ', ';', [rfReplaceAll]);
  CCDRoad.Delimiter := ';';
  CCDRoad.DelimitedText := CCDRoad.Text;
  CCDRoad.Delete(0);
  Application.ProcessMessages;
  New := TTSPIndividual.Create(EditNoCities.Value);

  MainForm.MemoCCD.Lines.Add('·��: ');
  sqr0 := 0;
  for ii := 0 to EditNoCities.Value - 2 do
  begin
    i := StrToInt(CCDRoad[ii]);
    j := StrToInt(CCDRoad[ii + 1]);
    x1 := trunc(MainForm.Display.Controller.Cities[i].X);
    y1 := trunc(MainForm.Display.Controller.Cities[i].Y);
    x2 := trunc(MainForm.Display.Controller.Cities[j].X);
    y2 := trunc(MainForm.Display.Controller.Cities[j].Y);

    sqr0 := sqr0 + sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  end;
  i := StrToInt(CCDRoad[0]);
  j := StrToInt(CCDRoad[EditNoCities.Value - 1]);
  x1 := trunc(MainForm.Display.Controller.Cities[i].X);
  y1 := trunc(MainForm.Display.Controller.Cities[i].Y);
  x2 := trunc(MainForm.Display.Controller.Cities[j].X);
  y2 := trunc(MainForm.Display.Controller.Cities[j].Y);

  sqr0 := sqr0 + sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  MemoCCD.Lines.Add('��·����' + floattostr(sqr0));

  for i := 0 to EditNoCities.Value - 1 do
  begin
    MainForm.MemoCCD.Lines.Add(MainForm.PMemo[StrToInt(CCDRoad[i])]);
    New.RouteArray[i] := StrToInt(CCDRoad[i]);
  end;

  MainForm.R_CCD := New;
  MainForm.Display.DrawMapWithRoute(New, 7);
  CCDRoad.DisposeOf;
end;

procedure TMainForm.ClearGraph;
begin
  Display.Clear;

end;

procedure TMainForm.pFitPaint(Sender: TObject);
begin
  DrawFit;
end;

procedure TMainForm.DisplayPaint(Sender: TObject);
begin
  Display.DrawMapWithRoute(Population[0] as ITSPIndividual);
end;

procedure TMainForm.DrawFit;

begin

end;

procedure TMainForm.Plot(D: TFloat);

begin

end;

procedure TMainForm.ButtonStepClick(Sender: TObject);
begin
  Population.Generation;
  Display.DrawMapWithRoute(Population[0] as ITSPIndividual);
  Generations := Generations + 1;
  Plot(Population.FitnessOf(0));
end;

procedure TMainForm.ButtonRunClick(Sender: TObject);
var
  i: Integer;
begin
  KillerPercentage.Percentage := SpinEdit3.Value; // 50
  Mutator.Transposition := SpinEdit4.Value; // 50
  Mutator.Inversion := SpinEdit5.Value; // 50
  for i := 1 to EditGens.Value do
  begin
    Population.Generation;
    R_SGA := (Population[0] as ITSPIndividual);
    Display.DrawMapWithRoute(Population[0] as ITSPIndividual);
    Generations := Generations + 1;
    Plot(Population.FitnessOf(0));
    Application.ProcessMessages;
  end;
  // Display.DrawMapWithRoute(Population[0] as ITSPIndividual);
  Memo1.Lines.Add('================');
  Memo1.Lines.Add('��·����' + floattostr(Population.FitnessOf(0))); // ����·�ܳ���
  Memo1.Lines.Add('·����');
  for i := 0 to (Population[0] as ITSPIndividual).Steps - 1 do
    // Memo1.Lines.Add('P' + INTtostr((Population[0] as ITSPIndividual)
    // .RouteArray[i]));
    MainForm.Memo1.Lines.Add(MainForm.PMemo[(Population[0] as ITSPIndividual)
      .RouteArray[i]]);
end;

procedure TMainForm.PopulationChange(Sender: TObject);
begin
end;

procedure TMainForm.PSOHelpClick(Sender: TObject);
var
  fn: string;
begin
  FA1.Caption := '����Ⱥ�㷨˵��';
  fn := stringreplace(extractfilepath(Application.ExeName) + '\����Ⱥ�㷨˵��.txt',
    '\\', '\', []);
  FA1.RzMemo1.Lines.LoadFromFile(fn);
  FA1.ShowModal;
end;

procedure TMainForm.helpClick(Sender: TObject);
var
  www1: tmemorystream;
begin
  {
    ProgressBar1.Visible := true;
    ProgressBar1.Min := 0; //��=1�����������0ʱ��
    ProgressBar1.Max := 0 ;    //Max< Min  ,error
    ProgressBar1.Position:=1;  //Position>Max,NO error
    exit;
  }
  // FOR   TEST
  // ShellExecute(self.handle, 'open', '˵��.txt', '', nil, SW_SHOWNORMAL);

  { www1 := TMemoryStream.Create;
    www1.Position := 0;
    F_TxtReader.Memo1.Lines.SaveToStream(www1);
    www1.Position := 0;
    F_TxtReader.Editor.Lines.LoadFromStream(www1);
    www1.Free;
    F_TxtReader.Show; }
  if FileExists('˵��.txt') then
  begin
    ShellExecute(self.handle, 'open', '˵��.txt', '', nil, SW_SHOWNORMAL);
  end;

  if not FileExists('˵��.txt') then
  begin
    www1 := tmemorystream.Create;
    www1.Position := 0;
    Memo_SaveToTxT.Lines.SaveToStream(www1);
    www1.Position := 0;
    FA1.RzMemo1.Lines.LoadFromStream(www1);
    www1.Free;
    FA1.ShowModal;
    Memo_SaveToTxT.Lines.SaveToFile('˵��.txt');
  end;

end;

procedure TMainForm.aboutClick(Sender: TObject);
begin

  U_OK.F_OK.initdata;
  U_OK.F_OK.ShowModal;
end;

procedure TMainForm.DyHelpClick(Sender: TObject);
var
  sss: Tstringlist;
begin
  sss := Tstringlist.Create;
  FA1.Caption := '��̬�滮�㷨˵��';
  sss.Add('�˶�̬�滮�㷨��');
  sss.Add('��������Ϊ 20  ʱ������Լʮ�룬 ');
  sss.Add('��������Ϊ 21  ʱ������Լ����ӣ�');
  sss.Add('��������Ϊ 22  ʱ������Լһ���ӣ�');
  sss.Add('������Ϊ 23  ʱ������ʱ��ʾ out of memory �� ');
  sss.Add('  �ڴ��ĵ���,���һ�ԡ�');
  sss.Add('');
  sss.Add('');

  // FA1.RzMemo1.Lines.Text := '�˶�̬�滮�㷨�� ' + #13#10 + '  ��������Ϊ 20  ʱ������Լʮ�룬  ' +
  // #13#10 + '  ��������Ϊ 21  ʱ������Լ����ӣ� ' + #13#10 + '  ��������Ϊ 22  ʱ������Լһ���ӣ� ' +
  // #13#10 + '  ������Ϊ 23  ʱ������ʱ��ʾ out of memory ���ڴ��ĵ���  ' + #13#10 + '  ���һ�ԡ�';
  FA1.RzMemo1.Lines.Text := sss.Text;
  sss.Free;
  FA1.ShowModal;
  // U_A1.FA1.ShowModal;
end;

procedure TMainForm.onebyoneHelpClick(Sender: TObject);
begin
  U_A2.F_A2.ShowModal;
end;

procedure TMainForm.generateHelpClick(Sender: TObject);
begin
  showmessage('���Ŵ��㷨��ʱ���ж���޽�������������´�����Ⱥ��OK�ġ�');
end;

procedure TMainForm.runfireClick(Sender: TObject);
var
  dp: TTFire;
begin
  self.showissetcity(0);
  ProgressBar5.Visible := True;
  ProgressBar5.min := 0;
  // ProgressBar5.max := trunc(power(2, (EditNoCities.Value)));
  ProgressBar5.Max := trunc(EditNoCities.Value);
  // ��Ȼ������йأ�����ĳ�����һ�䣬��Ȼ����������
  // ʲôԭ���ݲ������ݣ���˳���¹���̫�࣬�ݡ�
  ProgressBar5.Position := 0;
  Application.ProcessMessages;
  dp := TTFire.Create(EditNoCities.Value, self);
  dp.ProgressBar := ProgressBar5;
  dp.ProgressBarMax := ProgressBar5.Max;
  dp.ProgressBarpos := ProgressBar5.Position;

  dp.init;
  MainForm.Memo8.Lines.Add('��ʼʱ��: ' + formatdatetime
    ('yyyy-mm-dd hh:mm:ss', now()));
  dp.main;
  MainForm.Memo8.Lines.Add('����ʱ��: ' + formatdatetime
    ('yyyy-mm-dd hh:mm:ss', now()));
  dp.Free;

  ProgressBar5.Visible := false;
end;

procedure TMainForm.intonebyoneClick(Sender: TObject);
var
  dp: Tbranch;
  www: Double;
  s: string;
begin
  BranchStop := True;
  if 1 = 2 then
  begin
    s := ',0,4,7,5,1,3,8,6,2,';
    // s := ',0,7,4,2,6,8,3,1,5,';
    dp := Tbranch.Create(EditNoCities.Value, self);
    dp.init;
    // www := dp.getPathLength(s);
    dp.DisposeOf;
    self.Caption := 'fuck';
  end;
end;

procedure TMainForm.LKHiniClick(Sender: TObject);
begin
  U_LKH_ini.frmLKH_ini.ShowModal;
end;

procedure TMainForm.RzButtonCCDClick(Sender: TObject);
{
  var
  sss: Tstringlist;
  begin
  sss := Tstringlist.Create;
  FA1.Caption := 'concorde�㷨';
  sss.Add('�ٶ�����  tsp concorde���ҵ� http://www.math.uwaterloo.ca/tsp/concorde/DOC/README.html');
  sss.Add('concorde�㷨������������˵�Ǿ�ȷ�ⷨ��  ');
  sss.Add('��Ҳû��������������������㣬����ʵ�ã�������Դ��Ҳ����ʱ���� ');
  sss.Add(' ����վ��Դ�����أ�����㷨�ǿ�Դ�� ��');
  sss.Add('��LKH��concorde�㷨����Ҫ�޸��俪Դ��Դ���ٱ��룬�ſ���ʵ�ֵ����Ȩ��ֵ���Զ���߳��ȹ��ܣ������Դ��⹦��ȴ�����ã�δ���');
  sss.Add('');
  sss.Add('');

  FA1.RzMemo1.Lines.Text := sss.Text;
  sss.Free;
  FA1.ShowModal;
  // U_A1.FA1.ShowModal;
  end;
}
var
  fn: string;
begin
  FA1.Caption := 'concorde�㷨˵��';
  fn := stringreplace(extractfilepath(Application.ExeName) +
    '\concorde�㷨˵��.txt', '\\', '\', []);
  FA1.RzMemo1.Lines.LoadFromFile(fn);
  FA1.ShowModal;
end;

procedure TMainForm.RzLine2MouseEnter(Sender: TObject);
var
  www: TLabel;
  w111: Tstringlist;
  w1, w2, w3: string;
begin
  // LineBeforeColor,LableBeforeColor:TColor;
  LineBeforeColor := TRzLine(Sender).LineColor;
  TRzLine(Sender).LineColor := clBlue;
  www := TLabel(self.FindComponent('M' + TRzLine(Sender).Name));
  if www <> nil then
  begin
    LableBeforeColor := www.Font.Color;
    www.Font.Color := clBlue;
    www.BringToFront;

  end;
  w3 := TRzLine(Sender).Name;
  w3 := stringreplace(w3, '_1', '', []);
  w3 := stringreplace(w3, '_2', '', []);
  w3 := stringreplace(w3, '_3', '', []);
  w3 := stringreplace(w3, '_4', '', []);
  w3 := stringreplace(w3, '_5', '', []);
  w111 := Tstringlist.Create;
  w111.Delimiter := 'P';
  w111.DelimitedText := w3;
  w1 := 'P' + w111[1];
  w2 := 'P' + w111[2];
  TShape(self.FindComponent(w1)).BringToFront;
  www := TLabel(self.FindComponent('M' + w1));
  if www <> nil then
  begin
    www.Font.Color := clBlue;
    www.BringToFront;

  end;

  TShape(self.FindComponent(w2)).BringToFront;
  www := TLabel(self.FindComponent('M' + w2));
  if www <> nil then
  begin
    www.Font.Color := clBlue;
    www.BringToFront;

  end;
  w111.Free;

end;

procedure TMainForm.RzLine2MouseLeave(Sender: TObject);
var
  www: TLabel;
  w111: Tstringlist;
  w1, w2, w3: string;
begin
  TRzLine(Sender).LineColor := LineBeforeColor;
  www := TLabel(self.FindComponent('M' + TRzLine(Sender).Name));
  if www <> nil then
  begin
    www.Font.Color := LableBeforeColor;
    // www.BringToFront;

  end;
  w3 := TRzLine(Sender).Name;
  w3 := stringreplace(w3, '_1', '', []);
  w3 := stringreplace(w3, '_2', '', []);
  w3 := stringreplace(w3, '_3', '', []);
  w3 := stringreplace(w3, '_4', '', []);
  w3 := stringreplace(w3, '_5', '', []);
  w111 := Tstringlist.Create;
  w111.Delimiter := 'P';
  w111.DelimitedText := w3;
  w1 := 'P' + w111[1];
  w2 := 'P' + w111[2];
  TShape(self.FindComponent(w1)).BringToFront;
  www := TLabel(self.FindComponent('M' + w1));
  if www <> nil then
  begin
    www.Font.Color := clBlack; // LableBeforeColor;������̫�����õ�����
    www.BringToFront;

  end;

  TShape(self.FindComponent(w2)).BringToFront;
  www := TLabel(self.FindComponent('M' + w2));
  if www <> nil then
  begin
    www.Font.Color := clBlack; // LableBeforeColor;������̫�����õ�����
    www.BringToFront;

  end;
  w111.Free;
end;

procedure TMainForm.FormResize(Sender: TObject);
begin
  Display.SetRanges(0.0, 11.0, 0.0, 11.0, 1.0);
end;
function decodeMD5(old: string): string;
begin
  Result := UncrypKey(old, 'LJY888');
end;
function EncrypKey(Src1: string; Key: string): string;
var
  idx, i, j: Integer;
  KeyLen: Integer;
  KeyPos: Integer;
  offset: Integer;
  dest: string;
  SrcPos: Integer;
  SrcAsc: Integer;
  TmpSrcAsc: Integer;
  Range: Integer;
  Src: array of Integer;
  Src2: widestring;
begin

  Src2 := Src1;
  setlength(Src, Length(Src2) * 2 + 1);
  j := 0;
  for i := 0 to Length(Src2) - 1 do
  begin
    j := i * 2 + 1;
    Src[j] := (ord(Src2[i + 1]) div (16 * 16));
    // if src[j]=0 then src[j]:=1;
    Src[j + 1] := (ord(Src2[i + 1]) mod (16 * 16));

  end;
  KeyLen := Length(Key);
  if KeyLen = 0 then
    Key := 'Think   Space ';
  KeyPos := 0;
  SrcPos := 0;
  SrcAsc := 0;
  Range := 256;

  Randomize;
  offset := Random(Range);
  dest := format('%1.2x', [offset]);
  for SrcPos := 1 to Length(Src) - 1 do
  begin

    SrcAsc := (Src[SrcPos]);

    if KeyPos < KeyLen then
      KeyPos := KeyPos + 1
    else
      KeyPos := 1;
    SrcAsc := SrcAsc xor ord(Key[KeyPos]);
    dest := dest + format('%1.2x', [SrcAsc]);

  end;
  Result := dest;
end;

procedure TMainForm.FormShow(Sender: TObject);
var
  md5, md50: string;
begin
  // Memo7.Lines.Clear;
  // Memo7.Lines.LoadFromFile(extractfilepath(paramstr(0)) + 'md5.txt');
  // md5 := Memo7.Lines[1];

  md5 := Get_TAIL500_MD5ByFileName(paramstr(0));
  // showmessage(md5);
   //md5 := decodeMD5(md5);
  // showmessage(md5);
  if md5='' then  md5:= '11';

  md5[1] := '1';
  md5[2] := '1';
  md50 := Get_sub500_MD5ByFileName(paramstr(0));
  md50 := EncrypKey(md50, 'LJY888');
  md50[1] := '1';
  md50[2] := '1';

  if isdebug = 0 then
    if trim(md5) <> trim(md50) then
    begin
       application.Terminate;
       exit;

    //  FA1.Caption := 'www';
    //  FA1.RzMemo1.Text := 'md5  =' + md5 + #13#10 + 'md50=' + md50;
    //  FA1.WindowState:=wsMaximized;
    //  FA1.ShowModal;

    end;
  oriP.X := self.Shape1.Left;
  oriP.Y := self.Shape1.Top;
  self.WindowState := wsMaximized;
end;

function TMainForm.MoveLineLi(eee: TRzLine; p1x, p1y, p2x, p2y: Integer;
  truelength222, direct: string): boolean;
var
  ttt: TComponent;
begin
  eee.LineWidth := 2;
  eee.ArrowLength := 0;
  if (((min(p1x, p2x) = p1x) and (min(p1y, p2y) = p1y)) or
    ((min(p1x, p2x) = p2x) and (min(p1y, p2y) = p2y))) then
    eee.LineSlope := lsDown // ;//  lsDown   lsUp
  else
    eee.LineSlope := lsUp;
  eee.Hint := truelength222;
  // stringreplace(format('%f', [truelength]), '.00', '', []);
  // eee.ShowHint := true;
  eee.Left := min(p1x, p2x);
  eee.Top := min(p1y, p2y);
  // eee.Name := ADOQuery1.fieldbyname('ecode').AsString;
  // eee.Name := ADOQuery1.fieldbyname('ecode').AsString + 'E';
  // eee.Parent := self.ScrollBox1;
  eee.Width := Max(abs(p1x - p2x), 2); // ��setparent��width=1��������Ч��������Ч���ݡ�
  eee.Height := Max(abs(p1y - p2y), 2);
  if ((eee.Width = 2) or (eee.Height = 2)) then
    eee.LineWidth := 4;
  eee.Left := min(p1x, p2x);
  eee.Top := min(p1y, p2y);
  if pos('_1', eee.Name) > 0 then
  begin
    eee.Left := min(p1x, p2x) - 5;
    eee.Top := min(p1y, p2y) - 5;
  end;
  if pos('_2', eee.Name) > 0 then
  begin
    eee.Left := min(p1x, p2x) - 10;
    eee.Top := min(p1y, p2y) - 10;
  end;
  // if direct = '˫������޷���<-->' then
  if eee.Tag = 0 then
  else
  begin
    // if direct = '��Ŵ�Сָ��� -->' then
    if eee.Tag = 1 then
    begin
      { eee.top := min(p1y, p2y)-8;
        eee.Height := max(abs(p1y - p2y), 2)+12;
        eee.LineSlope := lsup ;
        eee.ArrowLength := 16;
        eee.ShowArrows:=saStart; }// saStart;saEnd
      // if eee.Name='P7P18' then
      // application.ProcessMessages;
      eee.LineWidth := 2;
      eee.ArrowLength := 16;
      eee.Top := min(p1y, p2y) - 8;
      eee.Height := Max(abs(p1y - p2y), 2) + 12;
      eee.Left := min(p1x, p2x) - 8;
      eee.Width := Max(abs(p1x - p2x), 2) + 12;
      if p1x <= p2x then
      begin
        eee.ShowArrows := saEnd;
        if p1y >= p2y then // P2
        begin // P1

          eee.LineSlope := lsUp;
        end
        else // P1
        begin //
          // P2
          eee.LineSlope := lsDown;

        end;
      end
      else
      begin
        eee.ShowArrows := saStart;
        if p1y >= p2y then
        begin // P2
          //
          eee.LineSlope := lsDown; // P1
        end
        else
        begin
          // P1
          eee.LineSlope := lsUp; // P2

        end; // P2     P2
        // P1
      end; // P2     P2

    end
    // else if direct = '��ŴӴ�ָ��С <--' then
    else if eee.Tag = 2 then
    begin
      eee.LineWidth := 2;
      eee.ArrowLength := 16;
      eee.Top := min(p1y, p2y) - 8;
      eee.Height := Max(abs(p1y - p2y), 2) + 12;
      eee.Left := min(p1x, p2x) - 8;
      eee.Width := Max(abs(p1x - p2x), 2) + 12;
      if p1x <= p2x then
      begin
        eee.ShowArrows := saStart; // P1     P1
        if p1y >= p2y then // P2               //      P2
        begin // P1                                 //   P1     P1

          eee.LineSlope := lsUp;
        end
        else
        begin // P1
          //
          eee.LineSlope := lsDown; // P2

        end;
      end
      else
      begin
        eee.ShowArrows := saEnd;
        if p1y >= p2y then // P2
        begin //
          // P1
          eee.LineSlope := lsDown;
        end
        else
        begin // P1
          // P2
          eee.LineSlope := lsUp;

        end;
        // START,END,ֻ��X������
      end; // UP,DOWN��ֻ���Խ��ߡ�

    end

  end;

  // ttt := tlabel.Create(self);

  // ttt.Name := 'M' + eee.Name;
  ttt := nil;
  ttt := self.FindComponent('M' + eee.Name);
  if ttt <> nil then
  begin
    TLabel(ttt).Caption := eee.Hint;
    TLabel(ttt).Left := eee.Left + (eee.Width div 2);
    TLabel(ttt).Top := eee.Top + (eee.Height div 2)

  end;

  // ttt.Parent := self.ScrollBox1;
end;

procedure TMainForm.N1Click(Sender: TObject);
var
  NewString, nn, mm: string;
  ClickedOK: boolean;

begin
  nn := N1.Hint;
  // mm:=TLabel(self.FindComponent('M'+nn)).Name;
  NewString := TLabel(self.FindComponent('M' + nn)).Caption;
  ClickedOK := InputQuery('�����ʵ������', nn + ':', NewString);
  if ClickedOK then
  begin { NewString contains new input string }
    TLabel(self.FindComponent('M' + nn)).Caption := NewString;
    MainForm.PMemo[StrToInt(stringreplace(nn, 'P', '', []))] := NewString;

  end;

end;

procedure TMainForm.N2Click(Sender: TObject);
var
  NewString, nn, mm: string;
  ClickedOK: boolean;
  i: Integer;
  tt: TPoint3D;
begin
  // N1.Hint := TShape(Sender).Name;
  nn := N1.Hint;

  mm := TLabel(self.FindComponent('M' + nn)).Caption;
  i := StrToInt(nn.Replace('P', '', []));
  // NewString:=floattostr(MainForm.Display.Controller.Cities[i].z);
  NewString := floattostr(MainForm.Z[i]);

  ClickedOK := InputQuery('�����ʵ��Ȩ��ֵ��', nn + '(' + mm + ')' + ':', NewString);
  if ClickedOK then
  begin { NewString contains new input string }
    // MainForm.Display.Controller.Cities[i].z:=strtofloat(NewString);
    MainForm.Z[i] := strtofloat(NewString);
    tt.X := MainForm.X[i];
    tt.Y := MainForm.Y[i];
    tt.Z := MainForm.Z[i];
    MainForm.Display.Controller.SetCity(i, tt);
    TShape(self.FindComponent(nn)).Hint := 'P' + inttostr(i) + '  x=' +
      inttostr(trunc(MainForm.Display.Controller.Cities[i].X)) + '/y=' +
      inttostr(trunc(MainForm.Display.Controller.Cities[i].Y)) + '  ���Ȩ����' +
      floattostr(MainForm.Display.Controller.Cities[i].Z);

  end;

end;

procedure TMainForm.createantClick(Sender: TObject);
begin
  self.showissetcity(0);
  if aco <> nil then
  begin
    aco.Free;
    aco := nil;
  end;
  // TACO.Create(n, m, gMAX_GEN: integer; alpha, beta, rho, pheromone00: double;
  aco := TACO.Create(EditNoCities.Value, antNums.Value, gMAX_GEN.Value,
    alpha.Value, beta.Value, rho.Value / 100.00,
    pheromone.Value / 100.00, self);
  // ACO aco = new ACO(48, 100, 1000, 1.f, 5.f, 0.5f);
  // aco.init("c://data.txt");
  // aco.solve();
  aco.init;
  aco.solve;
  // aco.free;
  // aco:=nil;
  // freeandnil(aco);
  runant.Enabled := True;
end;

procedure TMainForm.runantClick(Sender: TObject);
begin
  aco.setg(antNums.Value, gMAX_GEN.Value, alpha.Value, beta.Value,
    rho.Value / 100.00, pheromone.Value / 100.00);
  aco.init;

  aco.solve;
end;

procedure TMainForm.exportPointsClick(Sender: TObject);
var
  www: Tstringlist;
  i, j, k, ii, jj: Integer;
  w2: string;
  rij: Double;
begin
  k := 0;
  if Application.MessageBox('�����������꣬���Ȩֵ��Ĭ��Ϊ0�����ߵ�Ȩֵ��Ĭ��Ϊ1�����Զ���߳���' + #13#10 +
    'Ĭ�Ͻ������Զ���߳���Ҫ��Ҫ�������еı߳����Զ���ĺ��Զ�����ģ���' + #13#10 + '���ǡ����������Զ���߳�' + #13#10 +
    '���񡿣��������еı߳����Զ���ĺ��Զ�����ģ�', '����', MB_YESNO) = idYes then
  begin
    k := 1;
  end;

  // MessageDlg   TMessageForm
  if self.SaveDialog1.Execute then
  begin
    www := Tstringlist.Create;
    www.Add('//  tspС�������ʵ���������ļ�txt��˵����');
    www.Add('//  �ŵ�����,ֱ������<����ֵ����/С��>,�������꾭γ��/������');
    www.Add('//  �Ƶ�Ȩ��,��Ȩ�����   ');
    www.Add('//  �Ǳ�Ȩ��<��Ӧ��ά���񣬱������ݿ���>');
    www.Add('//  �ȱ߳��Զ������ٳ�Ȩ��');
    www.Add('//  �ɱ߳��û��ֹ�����');
    www.Add('//  �ʲ�����ȫͼ,�����������б�');
    www.Add('//  �ˡ��������ڵı߳����ó�һ����������ʾ����ǲ���ͨ�ģ���Լ�������б߳����ܺ͵�����N�����������൱�ڹ��˵������ߺ�');
    www.Add('//  �򻯳����¸�ʽ����');
    www.Add('//  ��demo.txt����Ϊ����  ��������������ʵ㣬�ٱ���������ʽ��');
    www.Add('//  ����ע�⣬��Ŵ�0��ʼ�����Ҫ����������Ҫ������أ�ĩβΪ�գ���Ҫ�����ַ�');
    www.Add('//  ������ֵΪ��Ļ�������ֻ꣬����Ϊ��������������Ϊ�����������Դ�����Ļ���Զ����ֹ�������');
    www.Add('//  ������ǵ���γ�����꣬���Խ��������ֱ����������ʾ���ٳ������˵��ҳ˱ߵ�Ȩ����У����');
    www.Add('//  ��xy���һ�����Ǵ˵��Ȩ�����ٺ����Ǳߵ�Ȩ���������Ϊ׼�Ķ�ά�����Ӧ�ߵ�����,���հ��ߣ���1ΪĬ��ֵ');
    www.Add('//  ��������Զ���߳�,���Զ�����߳�,�������Ȩ�����������Ȩ���ͱ�Ȩ��ȡ��֮,��������Զ���߳��򸲸�ͬ����֮ǰ���߳�,����ֹ��֮���PiPj������֮���� ');
    www.Add('//  �޵�ǰһ�е�����,�����Pi,��x��y����,�ٵ��Ȩ��,�ٱߵ�Ȩ��,�������Զ���Ϊ1,�����#�ָ�Ϊ�Զ���߳�,ÿ����;�ָ�,��ֵ�Ͳ������Ķ���Ϊ���Զ�����������û��Զ����,��ǰ;;�ָ�ֵ��Ӧ����i,j��ֵ/Ȩ��/�Զ��峤��');
    www.Add('//  �߶�ά�����Ӧ����i,j,��i��j');
    www.Add('//  ���б�Խ���PiPi�ɴ���Pi��Ȩ���������ⵥ��,����б�Խ���PiPi�Գ���ֵ��ͬ,�ݲ�����');
    www.Add('//  �����ڽ��������ڶ���ͬ�����ֵ�Ķ���·����������ٷ��ؿ��ҵ�����û�б���㷨���Ҿ�û�⹦��ȥ���ˡ�');
    www.Add('//ʾ����');
    www.Add('//P0: x=1;y=2#    p0��Ȩֵ#p0p0��Ȩֵ;p0p1��Ȩֵ;p0p2��Ȩֵ#p0p0�߳�;p0p1�߳�;p0p2�߳�');
    www.Add('//P1: x=11;y=21#  p1��Ȩֵ#p1p0��Ȩֵ;p1p1��Ȩֵ;p1p2��Ȩֵ#p1p0�߳�;p1p1�߳�;p1p2�߳�');
    www.Add('//P2: x=111;y=211#p2��Ȩֵ#p2p0��Ȩֵ;p2p1��Ȩֵ;p2p2��Ȩֵ#p2p0�߳�;p2p1�߳�;p2p2�߳�');
    www.Add('//��С���������Ͽո����trim()');
    www.Add('//�ֲ���С����ʱ���������;;���ַָ������Ŀո��ֵ������Ĭ��ֵ1��0��-1');
    www.Add('//����ǰ׺ǰ�β������ĺ������е�ȫ��Ĭ��ֵ�����籾Ӧp0...pi...pn��ȫ�ģ�ֻ��ǰ��һ��p0..pn-5,û�к���ģ������pn-5...pn�͵���Ĭ��ֵ������ǵ���ߵ�ȨĬ����1��������Զ���߳�Ĭ����0��-1�������ù��ɶ���/�ϴ����˹�����Զ�����ı߳�ʱ���⴦��');

    /// ֤ʵ�������ʵ����еľ���ȷ�ǶԽ��߶ԳƵ�

    for i := 0 to EditNoCities.Value - 1 do
    begin
      if MainForm.PMemo[i] = 'P' + inttostr(i) then
        w2 := 'P' + inttostr(i) + ': '
      else
        w2 := 'P' + inttostr(i) + '(' + MainForm.PMemo[i] + '): ';

      w2 := w2 + 'x=' + floattostr((MainForm.Display.Controller.Cities[i].X)) +
        ';y=' + floattostr((MainForm.Display.Controller.Cities[i].Y));
      w2 := w2 + '#' + floattostr
        ((MainForm.Display.Controller.Cities[i].Z)) + '#';
      w2 := w2 + floattostr((MainForm.Display.Controller.EdgeWeight[i][0]));
      for j := 1 to EditNoCities.Value - 1 do
        w2 := w2 + ';' + floattostr
          ((MainForm.Display.Controller.EdgeWeight[i][j]));
      w2 := w2 + '#';
      if k = 1 then
      begin
        w2 := w2 + floattostr((MainForm.Display.Controller.Distance[i][0]));
        for j := 1 to EditNoCities.Value - 1 do
          w2 := w2 + ';' + floattostr
            ((MainForm.Display.Controller.Distance[i][j]));
      end;
      if k = 0 then
      begin
        for ii := 0 to EditNoCities.Value - 1 do
        begin

          MainForm.Display.Controller.curdistance[ii][ii] := 0;
          for jj := ii + 1 to EditNoCities.Value - 1 do
          begin
            rij := sqrt(((MainForm.Display.Controller.Cities[ii].X -
              MainForm.Display.Controller.Cities[jj].X) *
              (MainForm.Display.Controller.Cities[ii].X -
              MainForm.Display.Controller.Cities[jj].X) +
              (MainForm.Display.Controller.Cities[ii].Y -
              MainForm.Display.Controller.Cities[jj].Y) *
              (MainForm.Display.Controller.Cities[ii].Y -
              MainForm.Display.Controller.Cities[jj].Y)) / 1.0) *
              MainForm.Display.Controller.EdgeWeight[ii][jj];
            if MainForm.Display.Controller.Distance[ii][jj] = -1.0 then
            begin
              MainForm.Display.Controller.curdistance[ii][jj] := rij;
              MainForm.Display.Controller.curdistance[jj][ii] := rij;
            end
            else
            begin
              // ���� ����SQRT��������ȻҪ����Ȩ�����Զ���߳����ٳ�Ȩ����
              MainForm.Display.Controller.curdistance[ii][jj] :=
                MainForm.Display.Controller.Distance[ii][jj];
              MainForm.Display.Controller.curdistance[jj][ii] :=
                MainForm.Display.Controller.Distance[ii][jj];
            end;
          end;
        end;

        MainForm.Display.Controller.curdistance[EditNoCities.Value - 1]
          [EditNoCities.Value - 1] := 0;

        w2 := w2 + floattostr((MainForm.Display.Controller.curdistance[i][0]));
        for j := 1 to EditNoCities.Value - 1 do
          w2 := w2 + ';' + floattostr
            ((MainForm.Display.Controller.curdistance[i][j]));
      end;
      www.Add(w2);
    end;
    // www.SaveToFile('c:\data.txt');
    www.SaveToFile(SaveDialog1.FileName);
    www.Free;
    showmessage('ok');
  end;
end;

procedure TMainForm.importPointsClick(Sender: TObject);
var
  i, j, ii, xx, yy, i2: Integer;
  j2: Double;
  nn, str1: string;
  www, qq, fuck, curts: Tstringlist;
  tt, pp: TPoint3D;
begin
  if self.OpenDialog1.Execute then
  begin
    isload := 1;
    if aco <> nil then
      freeandnil(aco);
    if R_SGA <> nil then
      R_SGA := nil;
    // ���ֲ���FREE�ģ�������û��FREE
    if R_ACO <> nil then
      R_ACO := nil; // ���ֲ���FREE�ģ�������û��FREE
    if R_DP <> nil then
      R_DP := nil; // ���ֲ���FREE�ģ�������û��FREE
    if R_Branch <> nil then
      R_Branch := nil; // ���ֲ���FREE�ģ�������û��FREE
    if R_TFire <> nil then
      R_TFire := nil;
    // ������������Ĳ���FREE������Խ��Խ����Ҫ���´򿪻�����WIN��
    if R_LKH <> nil then
      R_LKH := nil;
    if R_CCD <> nil then
      R_CCD := nil;
    www := Tstringlist.Create;
    qq := Tstringlist.Create;
    curts := Tstringlist.Create;
    fuck := Tstringlist.Create;
    www.LoadFromFile(OpenDialog1.FileName);
    for i := www.Count - 1 downto 0 do
    begin
      if trim(www.Strings[i]) = '' then
        www.Delete(i);
      if trim(www.Strings[i])[1] = '/' then
        www.Delete(i);
    end;

    Population.Clear;
    Generations := 0;
    ClearGraph;
    setlength(X, www.Count);
    setlength(Y, www.Count);
    setlength(Z, www.Count);
    setlength(MainForm.PMemo, www.Count);
    MainForm.Display.Controller.CityCount := www.Count;
    for i := 0 to www.Count - 1 do
      for j := 0 to www.Count - 1 do
        MainForm.Display.Controller.EdgeWeight[i][j] := 1.0;
    for i := 0 to www.Count - 1 do
      for j := 0 to www.Count - 1 do
        MainForm.Display.Controller.Distance[i][j] := -1.0;
    EditNoCities.Value := www.Count;
    Display.Controller.CityCount := www.Count;
    for i := 0 to www.Count - 1 do
    begin // ��������BUG����������
      str1 := www.Strings[i];
      str1 := stringreplace(str1, 'p', 'P', [rfReplaceAll]);
      str1 := stringreplace(str1, 'X', 'x', [rfReplaceAll]);
      str1 := stringreplace(str1, 'Y', 'y', [rfReplaceAll]);
      str1 := stringreplace(str1, '��', ':', [rfReplaceAll]);
      str1 := stringreplace(str1, '��', ';', [rfReplaceAll]);

      str1 := stringreplace(str1, ' ', '', [rfReplaceAll]);

      str1 := stringreplace(str1, ' ', '', [rfReplaceAll]);
      str1 := stringreplace(str1, '��', '(', [rfReplaceAll]);
      str1 := stringreplace(str1, '��', ')', [rfReplaceAll]);
      curts.Delimiter := '#';
      curts.DelimitedText := str1;

      qq.Delimiter := ':';
      qq.DelimitedText := curts[0];
      nn := trim(qq.Strings[0]);
      nn := stringreplace(nn, 'P', '', [rfReplaceAll]);
      if pos('(', nn) > 0 then
      begin
        nn := stringreplace(nn, ')', '', [rfReplaceAll]);
        fuck.Clear;
        fuck.Delimiter := '(';
        fuck.DelimitedText := nn;
        ii := StrToInt(fuck[0]);
        MainForm.PMemo[ii] := fuck[1];

      end
      else
      begin
        ii := StrToInt(nn);
        MainForm.PMemo[ii] := 'P' + nn;
      end;
      nn := qq.Strings[1];
      qq.Clear;
      qq.Delimiter := ';';
      qq.DelimitedText := nn;
      if pos('x=', qq.Strings[0]) > 0 then
        nn := qq.Strings[0];
      if pos('x=', qq.Strings[1]) > 0 then
        nn := qq.Strings[1];
      xx := StrToInt(stringreplace(nn, 'x=', '', [rfReplaceAll]));
      if pos('y=', qq.Strings[0]) > 0 then
        nn := qq.Strings[0];
      if pos('y=', qq.Strings[1]) > 0 then
        nn := qq.Strings[1];
      yy := StrToInt(stringreplace(nn, 'y=', '', [rfReplaceAll]));

      tt.X := xx;
      tt.Y := yy;
      if curts.Count >= 2 then
      begin
        if trim(curts.Strings[1]) = '' then
          tt.Z := 0.0
        else
          tt.Z := strtofloat(curts.Strings[1]);
      end
      else
      begin
        tt.Z := 0.0
      end;
      MainForm.Display.Controller.SetCity(ii, tt);
      MainForm.X[ii] := trunc(tt.X);
      MainForm.Y[ii] := trunc(tt.Y);
      MainForm.Z[ii] := tt.Z;
      if curts.Count >= 3 then
      begin
        // MainForm.Display.Controller
        fuck.Clear;
        fuck.Delimiter := ';';
        fuck.DelimitedText := stringreplace(curts.Strings[2], '��', ';',
          [rfReplaceAll]);
        for i2 := 0 to fuck.Count - 1 do
        begin
          if trim(fuck[i2]) = '' then
            j2 := 1.0
          else
            j2 := strtofloat(trim(fuck[i2]));
          if MainForm.Display.Controller.EdgeWeight[ii][i2] = 1.0 then
          begin
            MainForm.Display.Controller.EdgeWeight[ii][i2] := j2;
            MainForm.Display.Controller.EdgeWeight[i2][ii] := j2;
          end;
        end;
        for i2 := fuck.Count to www.Count - 1 do
        begin
          j2 := 1.0;
          if MainForm.Display.Controller.EdgeWeight[ii][i2] = 1.0 then
          begin
            MainForm.Display.Controller.EdgeWeight[ii][i2] := j2;
            MainForm.Display.Controller.EdgeWeight[i2][ii] := j2;
          end;
        end;

      end;
      if curts.Count >= 4 then
      begin // MainForm.Display.Controller
        fuck.Clear;
        fuck.Delimiter := ';';
        fuck.DelimitedText := stringreplace(curts.Strings[3], '��', ';',
          [rfReplaceAll]);
        for i2 := 0 to fuck.Count - 1 do
        begin
          if trim(fuck[i2]) = '' then
            j2 := -1.0
          else
            j2 := strtofloat(trim(fuck[i2]));
          if MainForm.Display.Controller.Distance[ii][i2] = -1.0 then
          begin
            MainForm.Display.Controller.Distance[ii][i2] := j2;
            MainForm.Display.Controller.Distance[i2][ii] := j2;
          end;
        end;
        for i2 := fuck.Count to www.Count - 1 do
        begin
          j2 := -1.0; // �������һ�����ţ����Ѳ�
          if MainForm.Display.Controller.Distance[ii][i2] = -1.0 then
          begin
            MainForm.Display.Controller.Distance[ii][i2] := j2;
            MainForm.Display.Controller.Distance[i2][ii] := j2;
          end;
        end;
      end;
    end;
    // EditNoCities.Value := www.Count;
    // Display.Controller.CityCount := www.Count;
    Display.DrawMap;
    ButtonCreatePop.Enabled := True;
    qq.Free;
    www.Free;
    fuck.Free;
    curts.Free;
    ButtonCreatePop.Enabled := True;
    ButtonRun.Enabled := false;
    runant.Enabled := false;
    addcaption := '  ���������ļ�:' + OpenDialog1.FileName;
    self.Caption := maincapiton + addcaption;
  end;
end;

procedure TMainForm.customLengthClick(Sender: TObject);
var
  i, x1, y1, x2, y2, j, ii, jj: Integer;
  sqr0, rij: Double;
  www: string;
begin
  for ii := 0 to EditNoCities.Value - 1 do
  begin

    MainForm.Display.Controller.curdistance[ii][ii] := 0;
    for jj := ii + 1 to EditNoCities.Value - 1 do
    begin
      rij := sqrt(((MainForm.Display.Controller.Cities[ii].X -
        MainForm.Display.Controller.Cities[jj].X) *
        (MainForm.Display.Controller.Cities[ii].X -
        MainForm.Display.Controller.Cities[jj].X) +
        (MainForm.Display.Controller.Cities[ii].Y -
        MainForm.Display.Controller.Cities[jj].Y) *
        (MainForm.Display.Controller.Cities[ii].Y -
        MainForm.Display.Controller.Cities[jj].Y)) / 1.0) *
        MainForm.Display.Controller.EdgeWeight[ii][jj];
      if MainForm.Display.Controller.Distance[ii][jj] = -1.0 then
      begin
        MainForm.Display.Controller.curdistance[ii][jj] := rij;
        MainForm.Display.Controller.curdistance[jj][ii] := rij;
      end
      else
      begin
        // ���� ����SQRT��������ȻҪ����Ȩ�����Զ���߳����ٳ�Ȩ����
        MainForm.Display.Controller.curdistance[ii][jj] :=
          MainForm.Display.Controller.Distance[ii][jj];
        MainForm.Display.Controller.curdistance[jj][ii] :=
          MainForm.Display.Controller.Distance[ii][jj];
      end;
    end;
  end;

  MainForm.Display.Controller.curdistance[EditNoCities.Value - 1]
    [EditNoCities.Value - 1] := 0;

  sqr0 := 0;
  for ii := 0 to EditNoCities.Value - 2 do
  begin
    www := Memo3.Lines.Strings[ii];
    www := stringreplace(www, 'P', '', []);
    www := stringreplace(www, 'p', '', []);
    try
      i := StrToInt(www);
    except
      for jj := 0 to EditNoCities.Value - 1 do
        if MainForm.PMemo[jj] = trim(Memo3.Lines.Strings[ii]) then
        begin
          i := jj;
          break;
        end;
    end;
    www := Memo3.Lines.Strings[ii + 1];
    www := stringreplace(www, 'P', '', []);
    www := stringreplace(www, 'p', '', []);

    try
      j := StrToInt(www);
    except
      for jj := 0 to EditNoCities.Value - 1 do
        if MainForm.PMemo[jj] = trim(Memo3.Lines.Strings[ii + 1]) then
        begin
          j := jj;
          break;
        end;
    end;
    x1 := trunc(MainForm.Display.Controller.Cities[i].X);
    y1 := trunc(MainForm.Display.Controller.Cities[i].Y);
    x2 := trunc(MainForm.Display.Controller.Cities[j].X);
    y2 := trunc(MainForm.Display.Controller.Cities[j].Y);

    if MainForm.Display.Controller.Distance[i][j] = -1 then
      sqr0 := sqr0 + sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)) *
        MainForm.Display.Controller.EdgeWeight[i][j]
    else
      sqr0 := sqr0 + MainForm.Display.Controller.curdistance[i][j];

    sqr0 := sqr0;
  end;
  www := Memo3.Lines.Strings[0];
  www := stringreplace(www, 'P', '', []);
  www := stringreplace(www, 'p', '', []);
  try
    i := StrToInt(www);
  except
    for jj := 0 to EditNoCities.Value - 1 do
      if MainForm.PMemo[jj] = trim(Memo3.Lines.Strings[0]) then
      begin
        i := jj;
        break;
      end;
  end;
  www := Memo3.Lines.Strings[EditNoCities.Value - 1];
  www := stringreplace(www, 'P', '', []);
  www := stringreplace(www, 'p', '', []);
  try
    j := StrToInt(www);
  except
    for jj := 0 to EditNoCities.Value - 1 do
      if MainForm.PMemo[jj] = trim(Memo3.Lines.Strings[EditNoCities.Value - 1])
      then
      begin
        j := jj;
        break;
      end;
  end;
  x1 := trunc(MainForm.Display.Controller.Cities[i].X);
  y1 := trunc(MainForm.Display.Controller.Cities[i].Y);
  x2 := trunc(MainForm.Display.Controller.Cities[j].X);
  y2 := trunc(MainForm.Display.Controller.Cities[j].Y);
  if MainForm.Display.Controller.Distance[i][j] = -1 then
    sqr0 := sqr0 + sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)) *
      MainForm.Display.Controller.EdgeWeight[i][j]
  else
    sqr0 := sqr0 + MainForm.Display.Controller.curdistance[i][j];

  for i := 0 to EditNoCities.Value - 1 do
    sqr0 := sqr0 + MainForm.Display.Controller.Cities[i].Z;

  Memo3.Lines.Add('��·����' + floattostr(sqr0));
end;

procedure TMainForm.antsHelpClick(Sender: TObject);
var
  fn: string;
begin
  FA1.Caption := '��Ⱥ�㷨˵��';
  fn := stringreplace(extractfilepath(Application.ExeName) + '\��Ⱥ�㷨˵��.txt',
    '\\', '\', []);
  FA1.RzMemo1.Lines.LoadFromFile(fn);
  FA1.ShowModal;
end;

procedure TMainForm.Button8Click(Sender: TObject);
begin
  showall := 0;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.onlyshowgenerateClick(Sender: TObject);
begin
  // showall := 0;
  // Display.DrawMapWithRoute(nil);
  showall := 1;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.onlyshowantClick(Sender: TObject);
begin
  // showall := 0;
  // Display.DrawMapWithRoute(nil);
  showall := 2;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.runDyClick(Sender: TObject);
var
  dp: Tdp;
begin
  self.showissetcity(0);
  if EditNoCities.Value > 22 then
    if Application.MessageBox('������������22ʱ����̬�滮�����������Ҫ��Ҫ�������У�', '��ʾ', MB_YESNO) <> idYes
    then
      exit;
  ProgressBar3.Visible := True;
  ProgressBar3.min := 0;
  // ProgressBar3.Max:=trunc(power(2,(EditNoCities.Value)));
  ProgressBar3.Max := trunc(EditNoCities.Value);
  ProgressBar3.Position := 0;
  Application.ProcessMessages;
  dp := Tdp.Create(EditNoCities.Value, self);
  dp.ProgressBar := ProgressBar3;
  dp.ProgressBarMax := ProgressBar3.Max;
  dp.ProgressBarpos := ProgressBar3.Position;

  dp.init;
  MainForm.Memo4.Lines.Add('��ʼʱ��: ' + formatdatetime
    ('yyyy-mm-dd hh:mm:ss', now()));
  dp.main;
  MainForm.Memo4.Lines.Add('����ʱ��: ' + formatdatetime
    ('yyyy-mm-dd hh:mm:ss', now()));
  dp.Free;

  ProgressBar3.Visible := false;
end;

procedure TMainForm.onlyshowdyClick(Sender: TObject);
begin
  // showall := 0;
  // Display.DrawMapWithRoute(nil);
  showall := 3;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.help2Click(Sender: TObject);
begin
  ShellExecute(handle, nil, pchar(extractfilepath(Application.ExeName) +
    '\TSP������ѧģ��_�ٶȰٿ�.html'), nil, nil, SW_SHOWNORMAL);
end;

procedure TMainForm.runonebyoneClick(Sender: TObject);
var
  dp: Tbranch;
begin
  self.showissetcity(0);
  if EditNoCities.Value > 14 then
    if Application.MessageBox('������������14ʱ����֧�޽���ܻ����������Ҫ��Ҫ�������У�', '��ʾ', MB_YESNO)
      <> idYes then
      exit;
  ProgressBar4.Visible := True;
  ProgressBar4.min := 0;
  ProgressBar4.Max := trunc(power(2, (EditNoCities.Value)));
  // ProgressBar4.Max:=trunc(EditNoCities.Value);
  // ��Ȼ������йأ�����ĳ�����һ�䣬��Ȼ����������
  // ʲôԭ���ݲ������ݣ���˳���¹���̫�࣬�ݡ�
  ProgressBar4.Position := 0;
  Application.ProcessMessages;
  dp := Tbranch.Create(EditNoCities.Value, self);
  dp.ProgressBar := ProgressBar4;
  dp.ProgressBarMax := ProgressBar4.Max;
  dp.ProgressBarpos := ProgressBar4.Position;
  // dp.ProgressBarpos10 := ProgressBar4.Position;
  BranchStop := false;
  dp.init;
  MainForm.Memo6.Lines.Add('��ʼʱ��: ' + formatdatetime
    ('yyyy-mm-dd hh:mm:ss', now()));
  dp.main;
  BranchStop := false;
  MainForm.Memo6.Lines.Add('����ʱ��: ' + formatdatetime
    ('yyyy-mm-dd hh:mm:ss', now()));
  dp.Free;

  ProgressBar4.Visible := false;
end;

procedure TMainForm.runPSOClick(Sender: TObject);
var
  PSO: TPSO;
  vv: Tstringlist;
begin
  // if MainForm.Display.Controller.CityCount=0  then
  begin
    // showmessage('�����������ǩҳ�������������');
    // exit;
  end;
  self.showissetcity(0);

  vv := Tstringlist.Create;
  // vv.Add('citys='+inttostr(trunc(EditNoCities.Value))) ;     //������
  vv.Add('PSOnum=' + inttostr(PSOnum.Value)); // ������
  vv.Add('PSOws=' + inttostr(PSOws.Value)); // �����������ֵws:
  vv.Add('PSOw=' + inttostr(PSOw.Value)); // ����ϵ��w��
  vv.Add('PSOwe=' + inttostr(PSOwe.Value)); // ����������Сֵwe:
  vv.Add('PSOVv=' + inttostr(PSOVv.Value)); // ��֪ϵ����
  vv.Add('PSOc1=' + inttostr(PSOc1.Value)); // ����ѧϰ����c1��
  vv.Add('PSOc2=' + inttostr(PSOc2.Value)); // ���ѧϰ����c2��
  vv.Add('PSOiter=' + inttostr(PSOiter.Value)); // ��������iter��
  ProgressBar3.Visible := True;
  ProgressBar3.min := 0;
  // ProgressBar3.Max:=trunc(power(2,(EditNoCities.Value)));
  ProgressBar3.Max := trunc(EditNoCities.Value);
  ProgressBar3.Position := 0;
  Application.ProcessMessages;
  PSO := TPSO.Create(EditNoCities.Value, self, vv);
  vv.Free;
  PSO.ProgressBar := ProgressBar3;
  PSO.ProgressBarMax := ProgressBar3.Max;
  PSO.ProgressBarpos := ProgressBar3.Position;

  PSO.init;
  MainForm.PSOLine.Lines.Add('================');
  MainForm.PSOLine.Lines.Add
    ('��ʼʱ��: ' + formatdatetime('yyyy-mm-dd hh:mm:ss', now()));
  PSO.main;
  MainForm.PSOLine.Lines.Add
    ('����ʱ��: ' + formatdatetime('yyyy-mm-dd hh:mm:ss', now()));
  try
    PSO.Free;
  except
  end;
  try
    // PSO.DisposeOf;
  except
  end;
  try
    PSO := nil;
  except
  end;

  ProgressBar3.Visible := false;
end;

procedure TMainForm.onlyshowonebyoneClick(Sender: TObject);
begin
  // showall := 0;
  // Display.DrawMapWithRoute(nil);
  showall := 4;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.onlyshowPSOClick(Sender: TObject);
begin
  showall := 8;
  /// //////////////////  ������Ⱥδ�ĳ�����Ⱥ��
  Display.DrawMapWithRoute(nil);
  /// ///
end;

procedure TMainForm.onlyshowfireClick(Sender: TObject);
begin
  // showall := 0;
  // Display.DrawMapWithRoute(nil);
  showall := 5;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.runLKHClick(Sender: TObject);
var
  www, path: string;
  iii: Integer;
  wwwlist: Tstringlist;
  j: Integer;
begin
  self.showissetcity(0);
  path := extractfilepath(paramstr(0));
  // www:='"'+path+'LKH\'+'"'; //���֤ʵ���У���˫���Ų���
  www := path + 'LKH\'; // ·���к��ո�δ�ԣ�·���к������Ѳ���OK

  wwwlist := Tstringlist.Create;
  wwwlist.Add('NODE_COORD_SECTION');

  for j := 0 to EditNoCities.Value - 1 do
  begin
    wwwlist.Add(inttostr(j + 1) + ' ' +
      floattostr((MainForm.Display.Controller.Cities[j].X)) + ' ' +
      floattostr((MainForm.Display.Controller.Cities[j].Y)))
  end;
  wwwlist.Add('EOF');
  wwwlist.SaveToFile(www + 'www.tsp');

  wwwlist.Clear;
  wwwlist.LoadFromFile(www + 'LKH.ini');
  wwwlist.Values['DIMENSION'] := inttostr(EditNoCities.Value);
  wwwlist.SaveToFile(www + 'LKH.ini');
  wwwlist.Free;





  // www:='"'+ExtractFilePath(ParamStr(0))+'TEST_VC2010_LKH\lkh.exe" ljy888';
  // ShellExecute(
  // ShellExecute(0, 'open', PChar(www),nil, nil, SW_SHOWNORMAL);

  // www := extractfilepath(paramstr(0));
  // www := '"'+www + 'ProjV8Hotel.dll"';
  // ShellExecute(0, 'open',pchar('regsvr32.exe  '+www),'',nil, SW_SHOWNORMAL);  //SW_HIDE
  // WinExec(pchar('regsvr32 /s  ' + www), SW_SHOWNORMAL);
  // www:='lkh.exe ljy888';
  // WinExec(pchar(www), SW_SHOWNORMAL);
  if FileExists(www + 'LKHtour.txt') then
    deletefile(www + 'LKHtour.txt');
  if FileExists(www + 'LKH.OK') then
    deletefile(www + 'LKH.OK');
  while 1 = 1 do
  begin
    Application.ProcessMessages;
    if ((not FileExists(www + 'LKHtour.txt')) and
      (not FileExists(www + 'LKH.OK'))) then
      break;
  end;
  // WinExec(pchar(www), SW_HIDE	);
  ShellExecute(0, nil, pchar('lkh.exe'), 'ljy888', pchar(www), SW_HIDE);
  // ShellExecute(0, nil, PChar('lkh.exe'),'ljy888', PChar(www), SW_SHOWNORMAL);
  ProgressBar6.Visible := True;
  ProgressBar6.Max := 100;
  ProgressBar6.Position := 1;
  while 1 = 1 do
  begin
    ProgressBar6.Position := ProgressBar6.Position + 1;
    if ProgressBar6.Position = 100 then
      ProgressBar6.Position := 1;
    Application.ProcessMessages;
    if ((FileExists(www + 'LKHtour.txt')) and (FileExists(www + 'LKH.OK'))) then
      break;
    iii := Windows.GetTickCount;
    while Windows.GetTickCount - iii < 100 do
      Application.ProcessMessages;
  end;

  iii := Windows.GetTickCount;
  while Windows.GetTickCount - iii < 500 do
    Application.ProcessMessages;
  // memo1.Lines.LoadFromFile(www+'LKHtour.txt');
  // memo2.Lines.LoadFromFile(www+'LKH.OK');
  // ����֮ʱ��һ���ǵð�BAT�ļ�ɾ���ˣ�����
  ProgressBar6.Visible := false;
  self.LKH_printPath;
end;

procedure TMainForm.onlyshowLKHClick(Sender: TObject);
begin
  // showall := 0;
  // Display.DrawMapWithRoute(nil);
  showall := 6;
  Display.DrawMapWithRoute(nil);
end;

procedure TMainForm.RUNCCDClick(Sender: TObject);
var
  www, path: string;
  iii: Integer;
  wwwlist: Tstringlist;
  j: Integer;
begin
  self.showissetcity(0);
  path := extractfilepath(paramstr(0));
  // www:='"'+path+'LKH\'+'"'; //���֤ʵ���У���˫���Ų���
  www := path + 'concorde\'; // ·���к��ո�δ�ԣ�·���к������Ѳ���OK

  wwwlist := Tstringlist.Create;
  wwwlist.Add('NAME : attwww');
  wwwlist.Add('COMMENT : www capitals of the US (Padberg/Rinaldi)');
  wwwlist.Add('TYPE : TSP');
  wwwlist.Add('DIMENSION : ' + inttostr(EditNoCities.Value));
  wwwlist.Add('EDGE_WEIGHT_TYPE : ATT');
  wwwlist.Add('NODE_COORD_SECTION');

  for j := 0 to EditNoCities.Value - 1 do
  begin
    wwwlist.Add(inttostr(j + 1) + ' ' +
      floattostr((MainForm.Display.Controller.Cities[j].X)) + ' ' +
      floattostr((MainForm.Display.Controller.Cities[j].Y)))
  end;
  wwwlist.Add('EOF');
  wwwlist.SaveToFile(www + 'attwww.tsp');







  // www:='"'+ExtractFilePath(ParamStr(0))+'TEST_VC2010_LKH\lkh.exe" ljy888';
  // ShellExecute(
  // ShellExecute(0, 'open', PChar(www),nil, nil, SW_SHOWNORMAL);

  // www := extractfilepath(paramstr(0));
  // www := '"'+www + 'ProjV8Hotel.dll"';
  // ShellExecute(0, 'open',pchar('regsvr32.exe  '+www),'',nil, SW_SHOWNORMAL);  //SW_HIDE
  // WinExec(pchar('regsvr32 /s  ' + www), SW_SHOWNORMAL);
  // www:='lkh.exe ljy888';
  // WinExec(pchar(www), SW_SHOWNORMAL);
  if FileExists(www + 'attwww.sol') then
    deletefile(www + 'attwww.sol');
  if FileExists(www + 'attwww.mas') then
    deletefile(www + 'attwww.mas');
  if FileExists(www + 'attwww.pul') then
    deletefile(www + 'attwww.pul');
  if FileExists(www + 'attwww.sav') then
    deletefile(www + 'attwww.sav');
  while 1 = 1 do
  begin
    Application.ProcessMessages;
    if ((not FileExists(www + 'attwww.sol')) and
      (not FileExists(www + 'attwww.sav'))) then
      break;
  end;
  // WinExec(pchar(www), SW_HIDE	);
  Application.ProcessMessages;
  ShellExecute(0, nil, pchar('concorde.exe'), 'attwww.tsp', pchar(www),
    SW_HIDE);
  // ShellExecute(0, nil, PChar('lkh.exe'),'ljy888', PChar(www), SW_SHOWNORMAL);
  ProgressBarCCD.Visible := True;
  ProgressBarCCD.Max := 100;
  ProgressBarCCD.Position := 1;
  while 1 = 1 do
  begin
    ProgressBarCCD.Position := ProgressBarCCD.Position + 1;
    if ProgressBarCCD.Position = 100 then
      ProgressBarCCD.Position := 1;
    Application.ProcessMessages;
    if ((FileExists(www + 'attwww.sol')) and (FileExists(www + 'attwww.sav')))
    then
      break;
    iii := Windows.GetTickCount;
    while Windows.GetTickCount - iii < 100 do
      Application.ProcessMessages;
  end;

  iii := Windows.GetTickCount;
  while Windows.GetTickCount - iii < 500 do
    Application.ProcessMessages;
  // memo1.Lines.LoadFromFile(www+'LKHtour.txt');
  // memo2.Lines.LoadFromFile(www+'LKH.OK');
  // ����֮ʱ��һ���ǵð�BAT�ļ�ɾ���ˣ�����
  ProgressBarCCD.Visible := false;
  self.CCD_printPath;
end;

procedure TMainForm.LKH_printPath;
var
  LKHRoad: Tstringlist;
  New: ITSPIndividual;
  path: string;
  i: Integer;
  sqr0: Double;
  x1, y1, x2, y2, j, ii, jj: Integer;
begin
  path := extractfilepath(paramstr(0)) + 'LKH\';
  LKHRoad := Tstringlist.Create;
  LKHRoad.LoadFromFile(path + 'LKHtour.txt');
  LKHRoad.Text := stringreplace(LKHRoad.Text, ' ', ';', [rfReplaceAll]);
  LKHRoad.Delimiter := ';';
  LKHRoad.DelimitedText := LKHRoad.Text;
  New := TTSPIndividual.Create(EditNoCities.Value);

  MainForm.Memo9.Lines.Add('·��: ');
  sqr0 := 0;
  for ii := 0 to EditNoCities.Value - 2 do
  begin
    i := StrToInt(LKHRoad[ii]) - 1;
    j := StrToInt(LKHRoad[ii + 1]) - 1;
    x1 := trunc(MainForm.Display.Controller.Cities[i].X);
    y1 := trunc(MainForm.Display.Controller.Cities[i].Y);
    x2 := trunc(MainForm.Display.Controller.Cities[j].X);
    y2 := trunc(MainForm.Display.Controller.Cities[j].Y);

    sqr0 := sqr0 + sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));

  end;
  i := StrToInt(LKHRoad[0]) - 1;
  j := StrToInt(LKHRoad[EditNoCities.Value - 1]) - 1;
  x1 := trunc(MainForm.Display.Controller.Cities[i].X);
  y1 := trunc(MainForm.Display.Controller.Cities[i].Y);
  x2 := trunc(MainForm.Display.Controller.Cities[j].X);
  y2 := trunc(MainForm.Display.Controller.Cities[j].Y);

  sqr0 := sqr0 + sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  Memo9.Lines.Add('��·����' + floattostr(sqr0));

  for i := 0 to EditNoCities.Value - 1 do
  begin
    MainForm.Memo9.Lines.Add(MainForm.PMemo[StrToInt(LKHRoad[i]) - 1]);
    New.RouteArray[i] := StrToInt(LKHRoad[i]) - 1;
  end;

  MainForm.R_LKH := New;
  MainForm.Display.DrawMapWithRoute(New, 5);
  LKHRoad.DisposeOf;
end;

end.
